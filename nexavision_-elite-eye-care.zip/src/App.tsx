import { useState } from "react";
import Loader from "./components/Loader";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import EyeAnatomy from "./components/EyeAnatomy";
import Contact from "./components/Contact";
import ChatBot from "./components/ChatBot";
import { Eye, ShieldAlert, Award, Globe, HeartHandshake } from "lucide-react";

export default function App() {
  const [loading, setLoading] = useState(true);

  // Focus and Scroll handlers to allow direct connections
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="relative min-h-screen bg-dark-deep selection:bg-cyan-glow/35 selection:text-white">
      {/* Dynamic Cybernetic Loader */}
      <Loader onComplete={() => setLoading(false)} />

      {!loading && (
        <div className="animate-[vision-correct_1.2s_cubic-bezier(0.16,1,0.3,1)_forwards]">
          {/* Glass Navbar */}
          <Navbar
            onBookClick={() => scrollToSection("book")}
            onEmergencyClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))}
            onSymptomClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))}
          />

          {/* Cinematic Hero Map */}
          <Hero
            onBookClick={() => scrollToSection("book")}
            onEmergencyClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))}
            onSymptomClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))}
          />

          {/* Interactive Eye Anatomy nodes panel */}
          <EyeAnatomy />

          {/* Booking slot form + target map */}
          <Contact />

          {/* Premium Luxury Footer */}
          <footer className="border-t border-white/5 bg-slate-950/80 pt-20 pb-10 px-6 relative overflow-hidden text-left font-sans">
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
              
              {/* Corporate branding */}
              <div className="flex flex-col gap-4">
                <a href="#" className="flex items-center gap-2.5">
                  <div className="h-9 w-9 rounded-full bg-cyan-glow/10 border border-cyan-glow/30 flex items-center justify-center">
                    <Eye className="h-4.5 w-4.5 text-cyan-light" />
                  </div>
                  <span className="font-display font-black text-base uppercase tracking-wider text-white">
                    AURAVISION
                  </span>
                </a>
                <p className="text-slate-400 text-xs leading-relaxed font-light">
                  AuraVision stands as Europe&apos;s leading micro-precision refractive group, delivering Swiss ophthalmic luxury and 0% APY medical installations.
                </p>
                <div className="flex gap-3 text-slate-500 font-mono text-[9px] uppercase tracking-wider mt-2">
                  <span>CHE-224.891.011 VAT</span>
                  <span>|</span>
                  <span>ZURICH CLINICAL REGISTER</span>
                </div>
              </div>

              {/* Useful anchors */}
              <div className="flex flex-col gap-4">
                <h4 className="font-mono text-[9px] text-slate-400 uppercase tracking-widest block font-bold">
                  Surgical Specialty Units
                </h4>
                <div className="flex flex-col gap-2.5 text-xs text-slate-400 font-light cursor-pointer">
                  <span onClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))} className="hover:text-cyan-light transition-colors">Micro-Refractive Wavefront LASIK</span>
                  <span onClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))} className="hover:text-cyan-light transition-colors">Blade-Free Catalys Cataract Care</span>
                  <span onClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))} className="hover:text-cyan-light transition-colors">Collagen Corneal Cross-Linking</span>
                  <span onClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))} className="hover:text-cyan-light transition-colors">PASCAL Selective Retina Sutureless Laser</span>
                </div>
              </div>

              {/* Quality Accreditations logos */}
              <div className="flex flex-col gap-4">
                <h4 className="font-mono text-[9px] text-slate-400 uppercase tracking-widest block font-bold">
                  Clinical Certifications
                </h4>
                <div className="flex flex-col gap-3 font-mono text-[10px] text-slate-300">
                  <div className="flex items-center gap-2">
                    <Award className="h-4.5 w-4.5 text-cyan-glow" /> EU Gold Standard Approved
                  </div>
                  <div className="flex items-center gap-2">
                    <Globe className="h-4.5 w-4.5 text-cyan-glow" /> JCI Joint Commission International
                  </div>
                  <div className="flex items-center gap-2">
                    <HeartHandshake className="h-4.5 w-4.5 text-cyan-glow" /> ESMO Ophthalmic Assurance
                  </div>
                </div>
              </div>

              {/* Corporate Legal Overviews */}
              <div className="flex flex-col gap-4">
                <h4 className="font-mono text-[9px] text-slate-400 uppercase tracking-widest block font-bold">
                  Client Services
                </h4>
                <div className="flex flex-col gap-2.5 text-xs text-slate-400 font-light cursor-pointer">
                  <span onClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))} className="hover:text-cyan-light transition-colors">Zero-Percent Installments Contract</span>
                  <span onClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))} className="hover:text-cyan-light transition-colors">Accepted Ocular Insurance Networks</span>
                  <span onClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))} className="hover:text-cyan-light transition-colors">Intake Ward Direct Admission Protocol</span>
                  <span onClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))} className="hover:text-cyan-light transition-colors">Academic Cornea Research Papers</span>
                </div>
              </div>

            </div>

            {/* Strict Regulatory Medical Disclaimer */}
            <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/5 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              <div className="lg:col-span-8 p-4 bg-slate-900/35 border border-white/5 rounded-2xl flex gap-3.5 items-start">
                <ShieldAlert className="h-5.5 w-5.5 text-slate-400 shrink-0 mt-0.5" />
                <p className="text-[10px] text-slate-400 font-mono leading-relaxed uppercase">
                  <strong>REGULATORY HEALTH WAIVER:</strong> CLINICAL EVALUATIONS INDICATED WITHIN THE SYMPTOM SYSTEM OR PROVIDED BY CORE-AI VIRTUAL SPECIALIST SERVE ONLY AS PRELIMINARY SYMPTOM SCREENING ASSISTANCE. THESE RESULTS DO NOT CONSTITUTE PHYSICAL OPHTHALMIC ADVISEMENT OR ESTABLISH MANDATORY LICENSED Slit-Lamp DIAGNOSES. VISIT AURAVISION IN ZURICH FOR COMPREHENSIVE MEDICAL SIGHT BIOMETRICS.
                </p>
              </div>

              <div className="lg:col-span-4 text-center lg:text-right flex flex-col gap-1 tracking-wider text-[11px] text-slate-500">
                <span>© 2026 AuraVision Clinical Group AG. All registered rights reserved.</span>
                <span className="font-mono text-[9px] uppercase">Designed for Ocular Correction Excellence</span>
              </div>
            </div>
          </footer>
        </div>
      )}

      {/* Persistent global floating chatbot outside of animated containers */}
      {!loading && <ChatBot />}
    </div>
  );
}
