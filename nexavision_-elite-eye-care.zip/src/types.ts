export interface Doctor {
  id: string;
  name: string;
  role: string;
  title: string;
  education: string;
  specialty: string;
  image: string;
  experience: string;
  successRate: string;
  bio: string;
  availability: string[];
}

export interface Service {
  id: string;
  title: string;
  category: string;
  description: string;
  fullDetails: string;
  iconName: string; // Dynamic rendering
  technologies: string[];
  recoveryTime: string;
  successRate: string;
  priceEstimate: string;
  features: string[];
}

export interface OcularRegion {
  id: string;
  name: string;
  description: string;
  role: string;
  pathology: string;
  treatment: string;
  coordinates: { x: number; y: number; r: number }; // Relative percentage coordinates for interactive nodes
}

export interface Testimonial {
  id: string;
  name: string;
  age: number;
  treatment: string;
  quote: string;
  rating: number;
  recoveredIn: string;
  avatar: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  isDisclaimer?: boolean;
}

export interface Appointment {
  id?: string;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  service: string;
  doctor: string;
  notes?: string;
  status?: string;
  createdAt?: string;
}

export interface SymptomDiagnosis {
  probableCondition: string;
  severityLevel: "Low" | "Moderate" | "High" | "Critical";
  urgencyDescription: string;
  clinicalExplanation: string;
  expertSpecialist: string;
  recommendedDiagnostics: string[];
  disclaimer: string;
}
