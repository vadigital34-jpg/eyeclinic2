import { motion } from "motion/react";
import { Sparkles, ArrowRight, ShieldCheck, Heart, Cpu, FlameKindling } from "lucide-react";

interface HeroProps {
  onBookClick: () => void;
  onEmergencyClick: () => void;
  onSymptomClick: () => void;
}

export default function Hero({ onBookClick, onEmergencyClick, onSymptomClick }: HeroProps) {
  const stats = [
    {
      id: "stat-1",
      icon: <Heart className="h-6 w-6 text-cyan-light" />,
      value: "10,000+",
      label: "Happy Patients Restored",
      detail: "Over 99.8% visual correctness",
    },
    {
      id: "stat-2",
      icon: <Sparkles className="h-6 w-6 text-cyan-light" />,
      value: "15+ Years",
      label: "Ophthalmic Excellence",
      detail: "Board-certified chief surgeons",
    },
    {
      id: "stat-3",
      icon: <Cpu className="h-6 w-6 text-cyan-light" />,
      value: "Advanced AI",
      label: "Diagnostic Screening",
      detail: "Nano-level ocular aberration map",
    },
  ];

  const highlights = [
    "FDA-Approved Wavefront Custom LASIK",
    "Blade-Free Catalys® Cataract Lasers",
    "Symfony® Multi-Focal Lens Implants",
    "Optical Coherence Tomography (OCT)",
    "Thermal Pulsation Dry Eye Dryness Relief",
    "24/7 Corneal Emergency Hospital Ward",
    "AI-Synthesized Ophthalmic Scanning",
  ];

  return (
    <section
      id="hero"
      className="relative min-h-[105vh] bg-dark-deep overflow-hidden flex flex-col justify-center pt-24"
    >
      {/* Dynamic Grid Overlay & Cyber Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_35%,rgba(6,182,212,0.18)_0%,transparent_50%)]" />
      <div className="absolute inset-0 bg-[linear-gradient(rgba(2,5,18,0.7)_0%,#020512_100%)] z-[1]" />

      {/* Futuristic Grid Line Assets */}
      <div className="absolute inset-0 z-0 opacity-15">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" className="text-cyan-glow/30" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Interactive Laser Scanning Horizontal Line */}
      <div className="absolute top-[35%] left-0 w-full opacity-40 z-[1]">
        <div className="laser-scanner" />
      </div>

      {/* Floating abstract glowing circles */}
      <div className="absolute top-[20%] left-[10%] w-[400px] h-[400px] rounded-full bg-blue-500/5 mix-blend-screen filter blur-[80px] ambient-float-1 z-0" />
      <div className="absolute bottom-[20%] right-[10%] w-[500px] h-[500px] rounded-full bg-cyan-glow/5 mix-blend-screen filter blur-[100px] ambient-float-2 z-0" />

      {/* Hero content row */}
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10 w-full py-12">
        {/* Core Texts - LHS */}
        <div className="lg:col-span-7 flex flex-col gap-6 text-left">
          {/* Animated Chip Accent */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 self-start py-1.5 px-4 rounded-full bg-cyan-glow/10 border border-cyan-glow/30"
          >
            <ShieldCheck className="h-4 w-4 text-cyan-light animate-pulse" />
            <span className="font-mono text-[10px] uppercase tracking-wider text-cyan-light font-bold">
              PREMIER OPHTHALMIC CENTER OF SWITZERLAND & USA
            </span>
          </motion.div>

          {/* Premium Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-display text-4xl sm:text-5xl md:text-6xl font-black text-white hover:text-white transition-all tracking-tight leading-[1.05]"
          >
            Advanced Vision Care <br />
            <span className="bg-gradient-to-r from-cyan-light via-blue-400 to-cyan-glow bg-clip-text text-transparent text-glow-cyan">
              For A Clearer Tomorrow
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-slate-300 text-lg md:text-xl font-light leading-relaxed max-w-2xl"
          >
            Experience Europe&apos;s leading micro-wavefront laser surgery and AI-powered eye diagnostics. Tailored ocular treatments administered by world-renowned specialists within a luxurious clinical environment.
          </motion.p>

          {/* CTA Buttons - Premium interactions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mt-4"
          >
            <button
              onClick={onBookClick}
              className="px-8 py-4 rounded-full bg-gradient-to-r from-cyan-glow to-cyan-light hover:brightness-110 text-dark-deep font-sans font-extrabold text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_4px_30px_rgba(6,182,212,0.35)] hover:scale-[1.02] transition-all duration-300 cursor-pointer"
            >
              Book Private Consultation
              <ArrowRight className="h-4 w-4" />
            </button>

            <button
              onClick={onEmergencyClick}
              className="px-8 py-4 rounded-full bg-slate-900/60 border border-red-500/30 hover:bg-red-500/10 hover:border-red-500/50 text-red-400 font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all duration-300 cursor-pointer"
            >
              <FlameKindling className="h-4 w-4 text-red-500 animate-pulse" />
              Emergency Eye Intake
            </button>

            <button
              onClick={onSymptomClick}
              className="hidden md:inline-flex px-5 py-3 text-slate-300 hover:text-cyan-light font-mono text-xs uppercase tracking-wider items-center gap-1 cursor-pointer"
            >
              ⚡ Instant AI Check
            </button>
          </motion.div>
        </div>

        {/* Cinematic Illustration - RHS */}
        <div className="lg:col-span-5 relative mt-8 lg:mt-0 flex items-center justify-center z-10 select-none">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative w-full max-w-md aspect-square flex items-center justify-center h-80 md:h-96"
          >
            {/* Dynamic rotating scanner circle backdrop */}
            <div className="absolute inset-0 rounded-full border border-white/5 bg-gradient-to-b from-cyan-glow/10 to-transparent p-1 animate-[spin_40s_linear_infinite]" />
            <div className="absolute inset-4 rounded-full border border-cyan-glow/20 bg-dark-deep animate-[spin_25s_linear_infinite_reverse]" />
            <div className="absolute inset-16 rounded-full border border-dashed border-cyan-light/20" />

            {/* Medical scanning visualizer image */}
            <img
              src="https://images.unsplash.com/photo-1579684389782-64d84b5e9053?auto=format&fit=crop&q=80&w=800"
              alt="Holographic Corneal Scanner"
              referrerPolicy="no-referrer"
              className="absolute inset-12 rounded-full object-cover filter brightness-[0.75] contrast-[1.1] border-2 border-cyan-glow/30 shadow-[0_0_50px_rgba(6,182,212,0.15)] group-hover:scale-105 transition-transform duration-700"
            />

            {/* Futuristic floating graphic nodes overlaying the eyeball visual */}
            <div className="absolute top-[20%] right-[10%] px-3 py-1.5 rounded-md bg-dark-deep/80 border border-cyan-light/30 backdrop-blur-md shadow-2xl animate-bounce">
              <span className="font-mono text-[9px] text-cyan-light font-bold flex items-center gap-1.5">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-cyan-light animate-ping" />
                CORNEA WAVEMAP ACTIVE
              </span>
            </div>

            <div className="absolute bottom-[10%] left-[8%] px-3 py-1.5 rounded-md bg-dark-deep/80 border border-blue-500/30 backdrop-blur-md shadow-2xl animate-pulse">
              <span className="font-mono text-[9px] text-blue-400 font-bold flex items-center gap-1.5">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-blue-500" />
                LASER CALIBRATED: 99.8%
              </span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Floating Interactive 3 Stats widgets */}
      <div className="max-w-7xl mx-auto px-6 w-full relative z-10 grid grid-cols-1 md:grid-cols-3 gap-6 my-10">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 + i * 0.1 }}
            className="group relative rounded-2xl glass-panel p-6 overflow-hidden flex items-center gap-5 cursor-pointer hover:border-cyan-light/30 transition-all duration-300"
          >
            {/* Hover inner pulse effect */}
            <div className="absolute -inset-x-20 -inset-y-20 bg-cyan-glow/5 mix-blend-screen opacity-0 group-hover:opacity-100 transition-opacity duration-500 rotate-12 blur-3xl" />

            <div className="h-12 w-12 rounded-full bg-cyan-glow/10 border border-cyan-glow/20 flex items-center justify-center shrink-0">
              {stat.icon}
            </div>

            <div>
              <div className="font-display font-extrabold text-2xl sm:text-3xl text-white tracking-tight flex items-center gap-1">
                {stat.value}
              </div>
              <div className="font-sans font-semibold text-slate-300 text-xs uppercase tracking-wide mt-0.5">
                {stat.label}
              </div>
              <div className="font-mono text-[10px] text-slate-500 mt-1">
                {stat.detail}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Continuous scrolling marquee of clinical achievements at bottom */}
      <div className="relative border-y border-white/5 bg-slate-950/45 py-4 w-full overflow-hidden mt-6 flex z-10">
        <div className="animate-marquee whitespace-nowrap flex gap-12 text-slate-400 text-xs font-mono font-bold uppercase tracking-widest items-center">
          {highlights.concat(highlights).map((text, idx) => (
            <div key={`high-1-${idx}`} className="flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-cyan-glow animate-ping" />
              <span>{text}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
