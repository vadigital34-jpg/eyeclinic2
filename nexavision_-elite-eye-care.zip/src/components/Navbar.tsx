import { useState, useEffect } from "react";
import { Eye, Menu, X, Calendar, FlameKindling } from "lucide-react";

interface NavbarProps {
  onBookClick: () => void;
  onEmergencyClick: () => void;
  onSymptomClick: () => void;
}

export default function Navbar({ onBookClick, onEmergencyClick, onSymptomClick }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Anatomy", href: "#anatomy" },
    { name: "Book Slot", href: "#book" }
  ];

  return (
    <nav
      id="auravision-navbar"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
        scrolled
          ? "bg-dark-deep/80 backdrop-blur-md border-b border-white/5 py-4 shadow-[0_4px_30px_rgba(3,7,18,0.3)]"
          : "bg-transparent py-6"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo container */}
        <a href="#" className="flex items-center gap-3 group">
          <div className="h-10 w-10 rounded-full bg-cyan-glow/10 border border-cyan-glow/30 flex items-center justify-center transition-all duration-300 group-hover:border-cyan-light group-hover:shadow-[0_0_15px_rgba(6,182,212,0.4)]">
            <Eye className="h-5 w-5 text-cyan-light transition-transform duration-500 group-hover:scale-110" />
          </div>
          <div>
            <div className="font-display font-black text-lg tracking-wider text-white uppercase flex items-center">
              AURAVISION
              <span className="text-[10px] ml-1.5 font-mono px-1.5 py-0.5 rounded bg-cyan-glow/20 border border-cyan-glow/30 text-cyan-light font-bold">
                X1
              </span>
            </div>
            <p className="font-mono text-[9px] text-slate-400 uppercase tracking-[0.2em] -mt-1">
              OPHTHALMIC SURGERY
            </p>
          </div>
        </a>

        {/* Desktop Navigation Link Menu */}
        <div className="hidden lg:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.name}
              href={item.href}
              className="text-sm font-medium text-slate-300 hover:text-cyan-light tracking-wide transition-colors duration-200 relative group"
            >
              {item.name}
              <span className="absolute bottom-[-6px] left-0 w-0 h-[2px] bg-gradient-to-r from-cyan-glow to-cyan-light transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </div>

        {/* CTA Button Group */}
        <div className="hidden lg:flex items-center gap-4">
          <button
            onClick={() => window.dispatchEvent(new CustomEvent("auravision-open-chat"))}
            className="px-3 py-2 text-xs font-mono font-bold tracking-wider text-cyan-light hover:text-white transition-colors uppercase cursor-pointer border border-cyan-glow/20 bg-cyan-glow/5 hover:bg-cyan-glow/10 rounded-full"
          >
            💬 24/7 AI CHAT
          </button>

          <button
            onClick={onSymptomClick}
            className="px-3 py-2 text-xs font-mono font-bold tracking-wider text-slate-300 hover:text-cyan-light transition-colors uppercase cursor-pointer"
          >
            AI DIAGNOSIS
          </button>
          
          <button
            onClick={onEmergencyClick}
            className="flex items-center gap-1.5 px-4 py-2 rounded-full border border-red-500/30 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-mono font-bold uppercase transition-all duration-300 cursor-pointer"
          >
            <FlameKindling className="h-3.5 w-3.5 text-red-500" />
            EMERGENCY CARE
          </button>

          <button
            onClick={onBookClick}
            className="relative px-6 py-2.5 rounded-full bg-cyan-glow text-dark-deep font-sans font-bold text-xs uppercase tracking-wider overflow-hidden transition-all duration-300 hover:scale-[1.03] shadow-[0_0_15px_rgba(6,182,212,0.4)] glow-btn-pulse cursor-pointer"
          >
            BOOK PRIVATE SLOT
          </button>
        </div>

        {/* Mobile menu triggers */}
        <div className="lg:hidden flex items-center gap-3">
          <button
            onClick={onEmergencyClick}
            className="p-2 rounded-full bg-red-500/15 border border-red-500/30 text-red-400"
          >
            <FlameKindling className="h-4 w-4" />
          </button>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="p-2 text-slate-300 hover:text-white"
          >
            {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-x-0 top-[72px] bg-dark-deep/95 backdrop-blur-lg border-b border-white/5 py-6 px-6 flex flex-col gap-6 shadow-2xl animate-[vision-correct_0.3s_ease-out]">
          <div className="flex flex-col gap-4">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="text-base font-semibold text-slate-300 hover:text-cyan-light py-1"
              >
                {item.name}
              </a>
            ))}
          </div>

          <hr className="border-white/5" />

          <div className="flex flex-col gap-3">
            <button
              onClick={() => {
                setMobileOpen(false);
                window.dispatchEvent(new CustomEvent("auravision-open-chat"));
              }}
              className="py-3 px-4 rounded-lg bg-cyan-glow/15 border border-cyan-glow/30 text-center text-cyan-light font-mono text-xs uppercase tracking-wider font-extrabold flex items-center justify-center gap-2"
            >
              <span>💬 24/7 AI CHAT CLINIC</span>
            </button>
            <button
              onClick={() => {
                setMobileOpen(false);
                onSymptomClick();
              }}
              className="py-3 px-4 rounded-lg bg-white/5 hover:bg-white/10 text-center text-slate-300 font-mono text-xs uppercase tracking-wider"
            >
              AI SYMPTOM SCREENER
            </button>
            <button
              onClick={() => {
                setMobileOpen(false);
                onBookClick();
              }}
              className="py-3 px-4 rounded-full bg-cyan-glow text-dark-deep text-center font-bold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(6,182,212,0.3)]"
            >
              BOOK APPOINTMENT
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
