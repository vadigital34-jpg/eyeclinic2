import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Eye, Info, Sparkles, AlertCircle } from "lucide-react";
import { OcularRegion } from "../types";

export default function EyeAnatomy() {
  const regions: OcularRegion[] = [
    {
      id: "cornea",
      name: "The Cornea",
      description: "The transparent outermost window that transmits and focuses light entering the eye.",
      role: "Responsible for about 65-75% of the eye's total focusing power.",
      pathology: "Myopia (Nearsightedness), Astigmatism, Keratoconus.",
      treatment: "Wavefront-Custom LASIK, Trans-PRK, Corneal collagen cross-linking.",
      coordinates: { x: 30, y: 50, r: 15 },
    },
    {
      id: "lens",
      name: "The Crystalline Lens",
      description: "The ultra-flexible natural crystalline convex element that shapes focus based on reading distances.",
      role: "Performs accommodation, allowing human focus to dynamically morph from distant panoramas to near text.",
      pathology: "Progressive Cataracts (clouding), Presbyopia (age-related reading blur).",
      treatment: "Blade-Free Robotic Cataract Laser surgery with Premium Symfony Multi-Focal Lens Implants.",
      coordinates: { x: 42, y: 50, r: 14 },
    },
    {
      id: "iris",
      name: "The Iris & Pupil",
      description: "The striking colorful vascular diaphragm controlling the diameter size of the dark pupil.",
      role: "Acts as a camera lens aperture, dilating or contracting to modulate appropriate photon flow based on illumination levels.",
      pathology: "Aniridia, acute iris pigment dispersion, pupillary block.",
      treatment: "Diagnostic gonioscopy, selective laser iridotomy (LI).",
      coordinates: { x: 38, y: 38, r: 10 },
    },
    {
      id: "retina",
      name: "The Retina Map",
      description: "Underlying network of microscopic photosensors (rods & cones) which converts photonic waves into neural sparks.",
      role: "The biological digital sensor array of the eye, translating colors, shapes, and movements.",
      pathology: "Retinal Tear/Detachment, Diabetic Maculopathy, age macular degeneration (AMD).",
      treatment: "Nano-pulse Retina Photocoagulation lasers, intravitreal micro-barrier injections.",
      coordinates: { x: 70, y: 45, r: 18 },
    },
    {
      id: "nerve",
      name: "The Optic Nerve",
      description: "The bundle of more than one million neural fibers transmitting ocular data feeds directly into the visual cortex.",
      role: "Acts as the high-speed fiber-optic trunk line linking biometric signals directly to human consciousness.",
      pathology: "Glaucoma (high tension fiber thinning), optical neuropathy.",
      treatment: "Pneumatic Applanation checkups, Micro-Invasive Glaucoma Surgery (MIGS), prescription droplets.",
      coordinates: { x: 85, y: 55, r: 12 },
    },
  ];

  const [activeRegion, setActiveRegion] = useState<OcularRegion>(regions[0]);

  return (
    <section id="anatomy" className="py-24 px-6 bg-slate-950 relative overflow-hidden">
      {/* Background decor glowing grid */}
      <div className="absolute top-[30%] left-[-10%] w-[500px] h-[500px] rounded-full bg-cyan-glow/5 filter blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10 text-center lg:text-left">
        {/* Title */}
        <div className="max-w-3xl mx-auto lg:mx-0 flex flex-col gap-3 mb-16">
          <span className="font-mono text-xs tracking-[0.3em] text-cyan-light uppercase font-bold">
            EDUCATIONAL INTERACTIVE BIOMETRICS
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
            Interactive Ocular Anatomy & Diagnostic Mapping
          </h2>
          <p className="text-slate-400 font-light text-base mt-2">
            Understand how different structures within your eye control human focusing capability. Click any glowing node on the interactive ocular schematic below to review relevant pathologies and treatments.
          </p>
        </div>

        {/* Board Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Interactive Eye Cross Section - LHS */}
          <div className="lg:col-span-6 relative flex justify-center bg-slate-900/45 border border-white/5 rounded-3xl p-6 md:p-12 overflow-hidden shadow-2xl h-[400px] md:h-[460px]">
            {/* Horizontal scanline active in box */}
            <div className="absolute inset-0 z-0">
              <div className="laser-scanner opacity-40" />
            </div>

            {/* Custom crafted SVG schematic */}
            <svg
              viewBox="0 0 100 100"
              className="w-full h-full max-w-sm md:max-w-md relative z-10 text-slate-700 select-none"
            >
              {/* Ocular orbit base contour */}
              <circle cx="58" cy="50" r="32" fill="rgba(8,16,40,0.3)" stroke="rgba(255,255,255,0.15)" strokeWidth="1.2" />

              {/* Sclera back layers */}
              <path d="M 58 18 A 32 32 0 0 1 85 66" fill="none" stroke="rgba(6,182,212,0.15)" strokeWidth="3" />

              {/* Cornea profile bulge (LHS) */}
              <path
                d="M 33 28 A 24 24 0 0 0 33 72"
                fill="rgba(34,211,238,0.1)"
                stroke="#22d3ee"
                strokeWidth="1.8"
                className="cursor-pointer"
                onClick={() => setActiveRegion(regions[0])}
              />

              {/* Crystalline Lens (Middle) */}
              <ellipse
                cx="42"
                cy="50"
                rx="4.5"
                ry="13"
                fill={activeRegion.id === "lens" ? "rgba(6, 182, 212, 0.4)" : "rgba(255,255,255,0.08)"}
                stroke={activeRegion.id === "lens" ? "#22d3ee" : "rgba(255,255,255,0.3)"}
                strokeWidth="1.5"
                className="cursor-pointer transition-colors duration-300"
                onClick={() => setActiveRegion(regions[1])}
              />

              {/* Iris bands surrounding the lens pupil gap */}
              <line x1="38" y1="28" x2="40" y2="37" stroke="#3b82f6" strokeWidth="2.5" />
              <line x1="38" y1="72" x2="40" y2="63" stroke="#3b82f6" strokeWidth="2.5" />

              {/* Pupil aperture (gap inside) */}
              <rect x="39" y="37" width="1.5" height="26" fill="transparent" />

              {/* Retina background glow curve */}
              <path
                d="M 50 20 A 30 30 0 0 1 80 70"
                fill="none"
                stroke={activeRegion.id === "retina" ? "#22d3ee" : "rgba(6, 182, 212, 0.25)"}
                strokeWidth={activeRegion.id === "retina" ? "2.5" : "1.5"}
                className="cursor-pointer transition-all duration-300"
                onClick={() => setActiveRegion(regions[3])}
              />

              {/* Optic Nerve exit tail (RHS bottom) */}
              <path
                d="M 83 62 C 87 64, 91 66, 94 65"
                fill="none"
                stroke={activeRegion.id === "nerve" ? "#22d3ee" : "rgba(255,255,255,0.25)"}
                strokeWidth="4"
                className="cursor-pointer transition-all duration-300"
                onClick={() => setActiveRegion(regions[4])}
              />
              <path
                d="M 85 55 C 89 57, 93 59, 96 58"
                fill="none"
                stroke={activeRegion.id === "nerve" ? "#22d3ee" : "rgba(255,255,255,0.25)"}
                strokeWidth="4"
                className="cursor-pointer transition-all duration-300"
                onClick={() => setActiveRegion(regions[4])}
              />

              {/* Interactive Pulsing hotspot pins */}
              {regions.map((region) => {
                const isActive = activeRegion.id === region.id;
                return (
                  <g key={region.id} className="cursor-pointer" onClick={() => setActiveRegion(region)}>
                    {/* Pulsing ring outer */}
                    <circle
                      cx={region.coordinates.x}
                      cy={region.coordinates.y}
                      r={isActive ? "3.5" : "1.8"}
                      fill="none"
                      stroke={isActive ? "#22d3ee" : "rgba(6, 182, 212, 0.4)"}
                      strokeWidth="0.8"
                    >
                      <animate
                        attributeName="r"
                        values={`${isActive ? "2.5;4.5;2.5" : "1.4;2.6;1.4"}`}
                        dur="2s"
                        repeatCount="indefinite"
                      />
                    </circle>
                    {/* Inner glowing core */}
                    <circle
                      cx={region.coordinates.x}
                      cy={region.coordinates.y}
                      r="1.2"
                      fill={isActive ? "#22d3ee" : "#3b82f6"}
                    />
                  </g>
                );
              })}
            </svg>

            {/* Instruction tooltip */}
            <div className="absolute bottom-4 left-6 right-6 text-center font-mono text-[10px] text-slate-400 bg-slate-950/80 py-1.5 px-3 rounded-full border border-white/5 z-20">
              💡 TAP GLOWING NODES ON DIAGRAM TO REVEAL SPECIFICATIONS
            </div>
          </div>

          {/* Biometric Readout panel - RHS */}
          <div className="lg:col-span-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeRegion.id}
                initial={{ opacity: 0, x: 25 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -25 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
                className="p-8 rounded-3xl glass-panel text-left flex flex-col gap-6 relative"
              >
                {/* Visual indicator corner */}
                <div className="absolute top-6 right-6 flex items-center gap-1 text-[9px] font-mono font-bold tracking-widest text-cyan-light border border-cyan-glow/20 bg-cyan-glow/10 px-2 py-0.5 rounded uppercase">
                  <Sparkles className="h-3 w-3 animate-spin" /> ACTIVE BIOMETRIC FEED
                </div>

                {/* Region title */}
                <div>
                  <h3 className="font-display font-extrabold text-2xl sm:text-3xl text-white tracking-tight flex items-center gap-2">
                    <Eye className="h-6 w-6 text-cyan-light" />
                    {activeRegion.name}
                  </h3>
                  <p className="text-slate-300 text-sm mt-2 leading-relaxed font-light">
                    {activeRegion.description}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 bg-slate-900/60 rounded-xl border border-white/5">
                    <span className="font-mono text-[9px] text-slate-500 uppercase tracking-widest block font-bold">
                      Functional Role
                    </span>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed font-light">
                      {activeRegion.role}
                    </p>
                  </div>

                  <div className="p-4 bg-slate-900/60 rounded-xl border border-white/5">
                    <span className="font-mono text-[9px] text-red-400 uppercase tracking-widest block font-bold">
                      Common Indications
                    </span>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed font-light">
                      {activeRegion.pathology}
                    </p>
                  </div>
                </div>

                {/* Treatment Matching Section */}
                <div className="mt-2 p-5 rounded-2xl bg-gradient-to-r from-cyan-glow/10 to-blue-900/10 border border-cyan-glow/20 flex gap-4 items-center">
                  <div className="p-3 bg-cyan-glow/10 rounded-xl">
                    <Info className="h-5 w-5 text-cyan-light" />
                  </div>
                  <div>
                    <span className="font-mono text-[9px] text-cyan-light uppercase tracking-widest block font-bold">
                      AuraVision Recommends
                    </span>
                    <h4 className="font-display text-base font-extrabold text-white mt-0.5 tracking-tight">
                      {activeRegion.treatment}
                    </h4>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
