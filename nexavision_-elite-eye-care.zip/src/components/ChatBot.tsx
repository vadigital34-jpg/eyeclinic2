import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Eye, MessageSquare, X, Send, Bot, Loader, Mic, MicOff, AlertCircle } from "lucide-react";
import { ChatMessage } from "../types";

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "initial-1",
      role: "assistant",
      content: "Welcome to AuraVision Ophthalmic Headquarters. I am your specialized Virtual Medical Care Coordinator. You can describe any aberrations you suffer from, discover custom laser therapies, or request guidance on clinic policies. How may I reassure and assist your vision choices today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);

  // Scroll anchor ref
  const lastMsgRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (lastMsgRef.current) {
      lastMsgRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isTyping]);

  useEffect(() => {
    const handleOpenChat = () => setIsOpen(true);
    window.addEventListener("auravision-open-chat", handleOpenChat);
    return () => window.removeEventListener("auravision-open-chat", handleOpenChat);
  }, []);

  const quickChips = [
    { label: "Describe LASIK Recovery 👁️", text: "Explain typical Wavefront LASIK recovery times and safety rates." },
    { label: "Urgent Chemical spill instructions 🚨", text: "I suspect chemical irritation or splashes in my eye. What must I do immediately?" },
    { label: "Are there 0% Interest EMIs? 💳", text: "Do you offer zero interest installations for surgeries?" },
    { label: "Book clinical scan slot 📅", text: "I wish to reserve a private diagnostic slot with Doctor Vance." },
  ];

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: Math.random().toString(),
      role: "user",
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText("");
    setIsTyping(true);

    try {
      const formattedHistory = messages.map(m => ({
        role: m.role,
        content: m.content
      }));
      formattedHistory.push({ role: "user", content: textToSend });

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: formattedHistory }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Ophthalmic link error.");
      }

      const botMsg: ChatMessage = {
        id: Math.random().toString(),
        role: "assistant",
        content: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      // Offline fallback indicator
      const errMsg: ChatMessage = {
        id: Math.random().toString(),
        role: "assistant",
        content: "Ocular AI Coordinator link was severed. However, our internal bio-registers suggest: If you require surgical bookings or immediate guidance, please call our emergency hotline directly at +1 (800) 555-AURA. Our staff stands prepared.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isDisclaimer: true
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const toggleMic = () => {
    // Elegant simulated ocular recording
    if (!isListening) {
      setIsListening(true);
      // Let speech recognition simulation run
      setTimeout(() => {
        setIsListening(false);
        setInputText("I need to book a clinical checkup with Dr. Marcus Thorne.");
      }, 3500);
    } else {
      setIsListening(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      
      {/* Dynamic Main Dashboard Box */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.85, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.85, y: 50 }}
            transition={{ type: "spring", stiffness: 150, damping: 20 }}
            className="w-[350px] sm:w-[410px] h-[550px] rounded-3xl bg-slate-900/90 backdrop-blur-xl border border-white/10 shadow-2xl overflow-hidden flex flex-col justify-between mb-4 text-left z-50 relative"
          >
            {/* Holographic matrix background line */}
            <div className="absolute top-0 left-0 w-full z-0 h-1"><div className="laser-scanner opacity-55" /></div>

            {/* Dashboard Header */}
            <div className="p-4 bg-slate-950/60 border-b border-white/5 flex items-center justify-between z-10">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 bg-cyan-glow/10 border border-cyan-glow/30 rounded-full flex items-center justify-center relative justify-center shrink-0">
                  <span className="absolute -inset-0.5 rounded-full border border-cyan-glow animate-ping shrink-0 scale-90" />
                  <Bot className="h-5 w-5 text-cyan-light shrink-0" />
                </div>
                <div>
                  <h4 className="font-display font-extrabold text-white text-xs uppercase flex items-center gap-1.5">
                    AURAVISION AI
                    <span className="inline-block h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                  </h4>
                  <p className="font-mono text-[9px] text-slate-400 uppercase tracking-widest mt-0.5">
                    Ocular Care Assistant
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-full border border-white/5 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Scrolling Chat log container */}
            <div className="flex-grow p-4 overflow-y-auto flex flex-col gap-4 relative">
              <div className="absolute inset-0 z-0 opacity-5 pointer-events-none">
                <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                  <rect width="100%" height="100%" fill="url(#grid)" />
                </svg>
              </div>

              <div className="z-10 flex flex-col gap-4">
                {messages.map((m) => {
                  const isUser = m.role === "user";
                  return (
                    <div
                      key={m.id}
                      className={`flex gap-3 max-w-[85%] ${
                        isUser ? "self-end flex-row-reverse" : "self-start"
                      }`}
                    >
                      {/* Avatar */}
                      {!isUser && (
                        <div className="h-7 w-7 bg-cyan-glow/10 border border-cyan-glow/25 text-cyan-light rounded-full p-1.5 flex items-center justify-center shrink-0 text-[10px] font-bold">
                          AI
                        </div>
                      )}

                      <div className="flex flex-col gap-1">
                        <div
                          className={`p-3.5 rounded-2xl text-xs font-light leading-relaxed ${
                            isUser
                              ? "bg-cyan-glow text-dark-deep rounded-tr-sm font-semibold"
                              : "bg-slate-950/85 border border-white/5 text-slate-200 rounded-tl-sm"
                          } ${m.isDisclaimer ? "border-red-500/20 bg-red-950/15 text-red-300" : ""}`}
                        >
                          {m.content}
                        </div>
                        <span className={`font-mono text-[8px] text-slate-500 block ${
                          isUser ? "text-right" : "text-left"
                        }`}>
                          {m.timestamp}
                        </span>
                      </div>
                    </div>
                  );
                })}

                {/* Typing status loader */}
                {isTyping && (
                  <div className="flex gap-3 max-w-[85%] self-start">
                    <div className="h-7 w-7 bg-cyan-glow/10 border border-cyan-glow/25 text-cyan-light rounded-full p-1.5 flex items-center justify-center shrink-0 text-[10px] font-bold">
                      AI
                    </div>
                    <div className="p-3 bg-slate-950/85 border border-white/5 rounded-2xl rounded-tl-sm text-xs text-slate-400 flex items-center gap-1.5 font-mono">
                      <Loader className="h-3.5 w-3.5 animate-spin text-cyan-light" />
                      Analyzing optical metrics...
                    </div>
                  </div>
                )}

                <div ref={lastMsgRef} />
              </div>
            </div>

            {/* Quick Chips suggestions bar */}
            <div className="px-4 py-2 flex items-center gap-2 overflow-x-auto border-t border-white/5 bg-slate-950/30 whitespace-nowrap scrollbar-none z-10 select-none">
              {quickChips.map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(chip.text)}
                  className="py-1.5 px-3 rounded-full bg-slate-900 border border-white/5 text-[9px] font-mono text-slate-300 hover:text-cyan-light hover:border-cyan-glow/30 transition-all cursor-pointer inline-block shrink-0"
                >
                  {chip.label}
                </button>
              ))}
            </div>

            {/* Input prompt tray */}
            <div className="p-4 bg-slate-950/60 border-t border-white/5 flex gap-2 items-center z-10">
              {/* Mic Icon for simulated speech */}
              <button
                onClick={toggleMic}
                className={`p-3 rounded-xl border transition-all cursor-pointer shrink-0 ${
                  isListening
                    ? "bg-red-500/20 border-red-500 text-red-400 glow-btn-pulse animate-pulse"
                    : "bg-slate-900 border-white/10 text-slate-400 hover:text-white"
                }`}
                title="Voice Assistant Integration"
              >
                {isListening ? <Mic className="h-4.5 w-4.5" /> : <MicOff className="h-4.5 w-4.5" />}
              </button>

              <div className="relative flex-grow">
                <input
                  type="text"
                  placeholder={isListening ? "Listening with wave capture..." : "Ask clinical questions..."}
                  value={inputText}
                  disabled={isListening}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleSendMessage(inputText);
                  }}
                  className="w-full bg-slate-900 p-3 rounded-xl border border-white/10 text-slate-200 text-xs font-light focus:border-cyan-glow focus:outline-none focus:ring-1 focus:ring-cyan-glow pr-10"
                />
                
                {/* Send */}
                <button
                  onClick={() => handleSendMessage(inputText)}
                  disabled={!inputText.trim()}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-cyan-light hover:brightness-110 transition-colors disabled:opacity-30 disabled:pointer-events-none cursor-pointer p-1"
                >
                  <Send className="h-4.5 w-4.5 shrink-0" />
                </button>
              </div>
            </div>

            {/* Listening Banner Overlay */}
            {isListening && (
              <div className="absolute inset-x-0 bottom-16 bg-red-950/90 border-t border-red-500/20 p-4 rounded-xl flex items-center justify-between text-left text-xs text-red-300 font-mono z-20 mx-4 shadow-xl animate-pulse">
                <span className="flex items-center gap-1.5">
                  <span className="inline-block h-2 w-2 rounded-full bg-red-500 animate-ping" />
                  OCULAR RECORDING VOICE TRANSCRIPTION
                </span>
                <span className="text-[10px] text-slate-400">00:0{Math.floor(Math.random()*4)}</span>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Trigger Area */}
      <div className="flex items-center gap-3">
        <motion.a
          href="https://wa.me/1800555AURA"
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="h-12 w-12 rounded-full bg-[#25D366] text-white shadow-[0_4px_25px_rgba(37,211,102,0.45)] flex items-center justify-center cursor-pointer pointer-events-auto shrink-0 transition-shadow hover:shadow-[0_4px_30px_rgba(37,211,102,0.6)]"
        >
          <svg className="h-6 w-6 fill-current" viewBox="0 0 24 24">
             <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.888-.788-1.487-1.761-1.663-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 00-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
          </svg>
        </motion.a>

        {!isOpen && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            whileHover={{ scale: 1.05 }}
            className="flex items-center gap-2 bg-slate-900/95 backdrop-blur-md border border-cyan-glow/40 px-3.5 py-2 rounded-2xl text-white cursor-pointer hover:border-cyan-glow/80 hover:bg-slate-900 shadow-[0_4px_25px_rgba(0,0,0,0.6)] select-none transition-all duration-300"
            onClick={() => setIsOpen(true)}
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-mono text-[10px] uppercase font-bold tracking-wider text-cyan-light">24/7 AI Care</span>
          </motion.div>
        )}

        <motion.button
          id="auravision-chatbot-trigger"
          onClick={() => setIsOpen(!isOpen)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="h-14 w-14 rounded-full bg-cyan-glow border border-cyan-light shadow-[0_4px_25px_rgba(6,182,212,0.45)] glow-btn-pulse flex items-center justify-center relative cursor-pointer z-50 text-dark-deep font-bold shrink-0"
        >
          <AnimatePresence mode="wait">
            {isOpen ? (
              <motion.div
                key="close-icon"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <X className="h-6 w-6" />
              </motion.div>
            ) : (
              <motion.div
                key="msg-icon"
                initial={{ rotate: 90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: -90, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="relative flex items-center justify-center h-full w-full"
              >
                <MessageSquare className="h-6 w-6" />
                <span className="absolute top-2 right-2.5 h-2 w-2 rounded-full bg-red-500 border-2 border-cyan-glow" />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>
      </div>
    </div>
  );
}
