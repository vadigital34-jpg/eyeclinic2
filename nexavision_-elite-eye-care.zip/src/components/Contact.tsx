import { useState, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Calendar, Phone, Mail, MapPin, Loader, Clock, CheckCircle, ShieldAlert } from "lucide-react";
import { Appointment } from "../types";

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [service, setService] = useState("Wavefront Custom LASIK & SMILE");
  const [doctor, setDoctor] = useState("Dr. Evelyn Vance, PhD");
  const [notes, setNotes] = useState("");

  const [loading, setLoading] = useState(false);
  const [confirmedAppt, setConfirmedAppt] = useState<Appointment | null>(null);
  const [errText, setErrText] = useState("");

  const services = [
    "Wavefront Custom LASIK & SMILE",
    "Blade-Free Robotic Cataract Laser",
    "Nano-Pulse Retina Therapy",
    "MIGS & Glaucoma Valve Care",
    "Myopia Control Pediatric Ocular",
    "Premium Ocular IPL & Tear Treatment",
    "Advanced Scleral Contacts",
    "Cornea Cross-Linking Therapy",
  ];

  const doctors = [
    "Dr. Evelyn Vance, PhD (LASIK Practitioner)",
    "Dr. Marcus Thorne, MD (Cataract Specialist)",
    "Dr. Samantha Al-Jamil, MD (Retina Specialist)",
  ];

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrText("");
    if (!name || !email || !phone || !date || !time) {
      setErrText("Please configure all mandatory fields: name, email, phone, date, and time.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          phone,
          date,
          time,
          service,
          doctor,
          notes,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Ocular slot synchronization failed.");
      }

      setConfirmedAppt(data.appointment);
      // Clean inputs
      setName("");
      setEmail("");
      setPhone("");
      setDate("");
      setTime("");
      setNotes("");
    } catch (err: any) {
      setErrText(err.message || "Network offline. Ophthalmic grid could not post details.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="book" className="py-24 px-6 bg-slate-950 relative overflow-hidden">
      {/* Decorative glows */}
      <div className="absolute top-[40%] right-[-10%] w-[500px] h-[500px] rounded-full bg-cyan-glow/5 filter blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Appointment Form - LHS */}
          <div className="lg:col-span-7">
            <div className="p-8 rounded-3xl bg-slate-900/60 border border-cyan-glow/20 shadow-[0_0_30px_rgba(6,182,212,0.1)] relative">
              <div className="laser-scanner opacity-20 absolute inset-x-0" />

              <div className="flex flex-col gap-2 text-left mb-8">
                <span className="font-mono text-[9px] text-cyan-light font-bold uppercase tracking-widest">
                  SECURE ADVANCED SLOT RESERVATION
                </span>
                <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Schedule Private Biometric Intake
                </h3>
                <p className="text-slate-400 text-xs font-light leading-relaxed">
                  Map your clinical slots directly onto our digital calendar grid. All bookings include wavefront topographies and standard digital ocular sweeps.
                </p>
              </div>

              {/* Status Box */}
              <AnimatePresence mode="wait">
                {confirmedAppt && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="mb-6 p-6 rounded-2xl bg-cyan-glow/10 border border-cyan-light/30 text-left"
                  >
                    <div className="flex items-center gap-2.5 text-cyan-light">
                      <CheckCircle className="h-5.5 w-5.5" />
                      <span className="font-mono text-xs font-bold uppercase tracking-wider">
                        APPOINTMENT DIRECTLY SYNCHRONIZED
                      </span>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-4 text-xs font-mono">
                      <div>
                        <span className="text-slate-500 block">PATIENT DESK</span>
                        <strong className="text-white font-sans">{confirmedAppt.name}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block">SURGICAL CODE</span>
                        <strong className="text-cyan-light">{confirmedAppt.id}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block">ESTIMATED SEGMENT</span>
                        <strong className="text-white font-sans">{confirmedAppt.date} @ {confirmedAppt.time}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block">ASSIGNED SURGEON</span>
                        <strong className="text-white font-sans">{confirmedAppt.doctor.split(" (")[0]}</strong>
                      </div>
                    </div>

                    <p className="text-[10px] text-slate-400 italic mt-4 border-t border-cyan-glow/20 pt-3 leading-normal">
                      ✅ A digital entrance passport and diagnostic instructions have been dispatched to <strong>{confirmedAppt.email}</strong>. Do not wear contact lenses for 24 hours prior to screening.
                    </p>

                    <button
                      onClick={() => setConfirmedAppt(null)}
                      className="mt-4 py-2 px-6 rounded-full bg-cyan-glow text-dark-deep font-sans font-bold text-xs uppercase cursor-pointer hover:brightness-110"
                    >
                      Book Another Consultation
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              {errText && (
                <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-400 font-mono flex items-center gap-2 text-left">
                  <ShieldAlert className="h-4.5 w-4.5 shrink-0" />
                  <span>{errText}</span>
                </div>
              )}

              {/* Core Form */}
              {!confirmedAppt && (
                <form onSubmit={onSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                  
                  {/* Full Name */}
                  <div className="flex flex-col gap-1.5 col-span-2">
                    <label className="font-mono text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                      Patient Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Charlotte Dubois"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-slate-950/80 p-3 rounded-lg border border-white/10 text-slate-200 text-xs font-medium focus:border-cyan-glow focus:outline-none focus:ring-1 focus:ring-cyan-glow transition-all"
                    />
                  </div>

                  {/* Email */}
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. charlotte@domain.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-950/80 p-3 rounded-lg border border-white/10 text-slate-200 text-xs font-medium focus:border-cyan-glow focus:outline-none focus:ring-1 focus:ring-cyan-glow transition-all"
                    />
                  </div>

                  {/* Phone */}
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                      Mobile Number *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. +41 (79) 555-5829"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-slate-950/80 p-3 rounded-lg border border-white/10 text-slate-200 text-xs font-medium focus:border-cyan-glow focus:outline-none focus:ring-1 focus:ring-cyan-glow transition-all"
                    />
                  </div>

                  {/* Primary Service */}
                  <div className="flex flex-col gap-1.5 col-span-2 md:col-span-1">
                    <label className="font-mono text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                      Surgic Unit / Treatment
                    </label>
                    <select
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      className="w-full bg-slate-950 p-3 rounded-lg border border-white/10 text-slate-200 text-xs font-medium focus:border-cyan-glow focus:outline-none"
                    >
                      {services.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Surgeon Choice */}
                  <div className="flex flex-col gap-1.5 col-span-2 md:col-span-1">
                    <label className="font-mono text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                      Preferred Specialist
                    </label>
                    <select
                      value={doctor}
                      onChange={(e) => setDoctor(e.target.value)}
                      className="w-full bg-slate-950 p-3 rounded-lg border border-white/10 text-slate-200 text-xs font-medium focus:border-cyan-glow focus:outline-none"
                    >
                      {doctors.map((d) => (
                        <option key={d} value={d}>
                          {d}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Date */}
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                      Preferred Date *
                    </label>
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-slate-950/80 p-3 rounded-lg border border-white/10 text-slate-200 text-xs font-medium focus:border-cyan-glow focus:outline-none focus:ring-1 focus:ring-cyan-glow transition-all"
                    />
                  </div>

                  {/* Time */}
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                      Preferred Time Block *
                    </label>
                    <input
                      type="time"
                      required
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="w-full bg-slate-950/80 p-3 rounded-lg border border-white/10 text-slate-200 text-xs font-medium focus:border-cyan-glow focus:outline-none focus:ring-1 focus:ring-cyan-glow transition-all"
                    />
                  </div>

                  {/* Notes */}
                  <div className="flex flex-col gap-1.5 col-span-2">
                    <label className="font-mono text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                      Ocular Aberrations / Medical History Notes
                    </label>
                    <textarea
                      placeholder="e.g. Wearing high astigmatism lenses since ten years. Experiencing progressive halo symptoms during rainy driving..."
                      rows={3}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full bg-slate-950/80 p-3 rounded-lg border border-white/10 text-slate-200 text-xs font-medium focus:border-cyan-glow focus:outline-none focus:ring-1 focus:ring-cyan-glow transition-all"
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="col-span-2 mt-2">
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full py-4 rounded-full bg-cyan-glow text-dark-deep font-sans font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_4px_25px_rgba(6,182,212,0.3)] hover:scale-[1.01] hover:brightness-110 active:scale-[0.99] transition-all cursor-pointer"
                    >
                      {loading ? (
                        <>
                          <Loader className="h-4 w-4 animate-spin" />
                          Calibrating Ocular Grid pathways...
                        </>
                      ) : (
                        "Map & Lock My Slot Reservation"
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>

          {/* Location & Map mockup - RHS */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* Direct details info card */}
            <div className="p-6 rounded-3xl glass-panel text-left flex flex-col gap-5">
              <h4 className="font-display font-extrabold text-white text-base tracking-tight uppercase">
                AuraVision Headquarters
              </h4>

              <div className="flex flex-col gap-4 text-xs font-light">
                <div className="flex gap-3.5 items-start">
                  <MapPin className="h-5 w-5 text-cyan-light shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-100 block font-semibold">Zurich Ocular Institute</strong>
                    <span className="text-slate-400">Bahnhofstrasse 100, 8001 Zurich, Switzerland</span>
                  </div>
                </div>

                <div className="flex gap-3.5 items-start">
                  <Phone className="h-5 w-5 text-cyan-light shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-100 block font-semibold">Concierge Line</strong>
                    <span className="text-slate-400">+41 (44) 555-8290</span>
                  </div>
                </div>

                <div className="flex gap-3.5 items-start">
                  <Mail className="h-5 w-5 text-cyan-light shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-100 block font-semibold">Direct Intake Desk</strong>
                    <span className="text-slate-400">admissions@auravision.ch</span>
                  </div>
                </div>

                <div className="flex gap-3.5 items-start">
                  <Clock className="h-5 w-5 text-cyan-light shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-100 block font-semibold">Operating Hours</strong>
                    <span className="text-slate-400">Mon - Fri: 08:00 - 18:00 | Saturday: By Appointment</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Simulated Cyber Ocular Map */}
            <div className="relative aspect-square rounded-3xl overflow-hidden border border-white/10 shadow-2xl bg-dark-deep hidden md:block">
              <div className="absolute inset-0 z-0 opacity-20">
                <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                  <rect width="100%" height="100%" fill="url(#grid)" />
                </svg>
              </div>

              {/* Map Layout Mock Graphically */}
              <div className="absolute inset-0 flex items-center justify-center">
                
                {/* Visual streets contours */}
                <div className="absolute w-[180%] h-1 bg-slate-800/40 rotate-[12deg] translate-y-10" />
                <div className="absolute w-[180%] h-1 bg-slate-800/40 rotate-[-45deg]" />
                <div className="absolute w-[180%] h-0.5 bg-cyan-glow/5 rotate-90" />
                
                {/* Concentric radar indicator scans */}
                <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="50%" cy="50%" r="60" fill="none" stroke="rgba(6,182,212,0.15)" strokeWidth="1" className="animate-[pulse_4s_infinite]" />
                  <circle cx="50%" cy="50%" r="100" fill="none" stroke="rgba(6,182,212,0.07)" strokeWidth="1" className="animate-[pulse_6s_infinite]" />
                </svg>

                {/* Pulsating target coordinate pin for AuraVision */}
                <div className="relative z-10">
                  <span className="absolute -inset-4 rounded-full bg-cyan-light/20 border border-cyan-glow animate-ping shrink-0" />
                  <div className="h-6 w-6 rounded-full bg-cyan-glow text-dark-deep border-4 border-slate-900 flex items-center justify-center shadow-2xl">
                    <MapPin className="h-3.5 w-3.5 -translate-y-[1px]" />
                  </div>
                </div>

                {/* HUD label mapping indicator */}
                <div className="absolute top-[40%] left-[55%] px-3 py-1.5 rounded bg-dark-deep/95 border border-cyan-glow/30 shadow-2xl select-none z-10 text-left">
                  <span className="font-mono text-[9px] text-cyan-light font-bold flex items-center gap-1.5">
                    <span className="inline-block h-1.5 w-1.5 rounded-full bg-cyan-light animate-ping" />
                    AUTON_MAP COORDINATES: [47.3769° N, 8.5417° E]
                  </span>
                </div>
              </div>

              <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between text-[8px] font-mono text-slate-500 z-10">
                <span>ZURICH SATELLITE RADAR</span>
                <span>HUD SCALE: 4KM</span>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
