import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Eye, Shield, Activity, Cpu } from "lucide-react";

interface LoaderProps {
  onComplete: () => void;
}

export default function Loader({ onComplete }: LoaderProps) {
  const [visible, setVisible] = useState(true);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("Calibrating holographic diagnostics...");

  const statusMessages = [
    "Initializing AuraVision diagnostic suite...",
    "Aligning micro-wavefront laser matrices...",
    "Securing clinical encryption pathways...",
    "AuraVision Core System: Online."
  ];

  useEffect(() => {
    // Increment progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setVisible(false);
            onComplete();
          }, 800);
          return 100;
        }
        
        // Update messages based on progress
        const msgIndex = Math.floor((prev / 100) * statusMessages.length);
        if (statusMessages[msgIndex] && statusMessages[msgIndex] !== statusText) {
          setStatusText(statusMessages[msgIndex]);
        }
        
        return prev + Math.floor(Math.random() * 8) + 4;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [onComplete, statusText]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          id="auravision-loader"
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-dark-deep"
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          {/* Futuristic ambient stars background */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(8,30,70,0.45)_0%,rgba(2,5,18,1)_80%)]" />

          {/* Holographic scanning circle visualizer */}
          <div className="relative mb-8 flex items-center justify-center h-48 w-48">
            {/* Outermost rotating orbit */}
            <motion.div
              className="absolute inset-0 rounded-full border border-dashed border-cyan-light/30"
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 12, ease: "linear" }}
            />

            {/* Pulsating mid-circle */}
            <motion.div
              className="absolute inset-2 rounded-full border border-cyan-glow/20"
              animate={{ scale: [0.95, 1.05, 0.95] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
            />

            {/* High Tech Crosshair */}
            <div className="absolute h-full w-2 border-t border-b border-cyan-glow/40" />
            <div className="absolute w-full h-2 border-l border-r border-cyan-glow/40" />

            {/* Glowing Ocular Iris Assembly */}
            <motion.div
              className="relative flex items-center justify-center bg-cyan-glow/5 h-28 w-28 rounded-full border border-cyan-glow shadow-[0_0_30px_rgba(6,182,212,0.3)]"
              animate={{
                boxShadow: ["0 0 20px rgba(6,182,212,0.2)", "0 0 40px rgba(34,211,238,0.5)", "0 0 20px rgba(6,182,212,0.2)"],
              }}
              transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
            >
              <Eye className="h-14 w-14 text-cyan-light" />
              
              {/* Ocular lasers scanline in loading */}
              <div className="laser-scanner rounded-full" />
            </motion.div>

            {/* Cyberscreen percentage readout */}
            <div className="absolute -bottom-16 text-center font-mono text-xs tracking-[0.25em] text-cyan-light font-bold">
              SYSTEM INTENSITY: {Math.min(progress, 100)}%
            </div>
          </div>

          {/* Lower branding elements */}
          <div className="z-10 text-center max-w-sm px-6">
            <motion.h1 
              className="font-display text-2xl font-bold tracking-[0.15em] text-white uppercase"
              initial={{ letterSpacing: "0.1em", opacity: 0 }}
              animate={{ letterSpacing: "0.15em", opacity: 1 }}
              transition={{ duration: 1 }}
            >
              AuraVision<span className="text-cyan-light text-glow-cyan font-light">Clinic</span>
            </motion.h1>
            
            <p className="mt-2 font-mono text-[10px] tracking-wider text-slate-400 uppercase h-4">
              {statusText}
            </p>

            {/* Sleek surgical progress bar */}
            <div className="mt-8 h-[2px] w-48 bg-slate-900 mx-auto rounded-full overflow-hidden relative">
              <motion.div
                className="h-full bg-gradient-to-r from-blue-500 via-cyan-glow to-cyan-light shadow-[0_0_8px_#22d3ee]"
                initial={{ width: "0%" }}
                animate={{ width: `${progress}%` }}
                transition={{ ease: "easeOut" }}
              />
            </div>

            {/* Cyber specs bar */}
            <div className="mt-6 flex justify-around text-slate-500 font-mono text-[9px] uppercase border-t border-slate-900/40 pt-4">
              <div className="flex items-center gap-1">
                <Shield className="h-3 w-3 text-cyan-glow" /> SAFE
              </div>
              <div className="flex items-center gap-1">
                <Activity className="h-3 w-3 text-cyan-glow" /> DIALED
              </div>
              <div className="flex items-center gap-1">
                <Cpu className="h-3 w-3 text-cyan-glow" /> AI SECURE
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
