import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());
const PORT = 3000;

// Lazy initialization of Gemini SDK
let ai: GoogleGenAI | null = null;
function getGemini() {
  if (!ai) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is not set. Chatbot and symptom checker will fall back to smart local algorithms.");
      return null;
    }
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return ai;
}

// In-memory records
const appointments: any[] = [];

// API: Health probe
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", timestamp: new Date().toISOString() });
});

// API: Save appointment
app.post("/api/appointments", (req, res) => {
  const { name, email, phone, date, time, service, doctor, notes } = req.body;
  if (!name || !email || !date || !time) {
    return res.status(400).json({ error: "Required fields are missing: name, email, date, time" });
  }
  const appt = {
    id: "AV-" + Math.floor(1000 + Math.random() * 9000),
    name,
    email,
    phone,
    date,
    time,
    service: service || "General Eye Consultation",
    doctor: doctor || "Available Premier Specialist",
    notes: notes || "",
    status: "Confirmed",
    createdAt: new Date().toISOString(),
  };
  appointments.push(appt);
  res.json({ success: true, appointment: appt });
});

// API: Get active appointments
app.get("/api/appointments", (req, res) => {
  res.json(appointments);
});

// API: Chat bot using Gemini
app.post("/api/chat", async (req, res) => {
  const { messages, userProfile } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid request payload. 'messages' array required." });
  }

  const client = getGemini();

  // If Gemini API is missing, use an ultra-premium simulated response
  if (!client) {
    const lastMsg = messages[messages.length - 1]?.content?.toLowerCase() || "";
    let reply = "I would be happy to help guide you. At AuraVision Studio, our leading surgeons offer custom wavefront LASIK, 3D laser cataract correction, and premium multi-focal lens implants. Would you like to check visual symptoms or register an appointment with one of our directors?";
    if (lastMsg.includes("appointment") || lastMsg.includes("book") || lastMsg.includes("schedule")) {
      reply = "To schedule your premier diagnostic consultation with AuraVision, you can use our dynamic appointment portal on this screen. Simply select your preferred specialist, date and time, and your slot will be instantly confirmed, including digital reminders.";
    } else if (lastMsg.includes("emergency") || lastMsg.includes("pain") || lastMsg.includes("injury") || lastMsg.includes("chemical")) {
      reply = "⚠️ EMERGENCY ALERT: If you are experiencing sudden severe eye pain, chemicals in the eyes, or flashes with black floaters, please flush with saline immediately and proceed to our 24/7 emergency corneal intake ward. You can call our emergency desk at +1 (800) 555-AURA for immediate guidance.";
    } else if (lastMsg.includes("lasik") || lastMsg.includes("specs") || lastMsg.includes("glasses")) {
      reply = "Our dual-laser wavefront LASIK surgery is customized to the micro-curvature of your cornea, taking under 10 minutes with rapid 24-hour visual recovery. AuraVision's success rate is over 99.8%. Do you currently wear thick glasses or have high astigmatism?";
    } else if (lastMsg.includes("cataract") || lastMsg.includes("cloudy")) {
      reply = "Our state-of-the-art Cataract treatment replaces cloudy natural lenses with ultra-high definition intraocular lenses (IOLs) like Symfony® Toric. This procedure is completely sutureless, blade-free, and restores rich, colorful panoramic vision.";
    }
    return res.json({ reply });
  }

  try {
    const formattedHistory = messages.map(m => {
      return {
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }],
      };
    });

    const systemPrompt = `You are "AuraVision Core-AI Coordinator", the ultra-premium virtual health specialist for AuraVision Clinic & Eye Hospital.
Your tone is soothing, clinical, sophisticated, and reassuring. Speak with elite healthcare hospitality.
Never use dry robotic phrases. Use markdown formatting to make your coordinates, tables, and treatments look pristine.
Reference procedures if asked:
1. Micro-Wavefront Customized LASIK (Dual laser corrective, 24h recovery, 99.8% precision)
2. Blade-Free Robotic Cataract Microsurgery (With panoramic multifocal lens options like Symfony/Vivity)
3. Smart Nano-Pulse Retina Laser Integration (For retinal tears or diabetic macular care)
4. Cornea Advanced Collagen Cross-linking & Keratoconus Therapy
5. Dry Eye Premium Tear-Therapy (Thermal pulsation, Intense Pulsed Light IPL)

Doctor Panel:
- Dr. Evelyn Vance (Chief Refractive Director, LASIK & SMILE Pioneer)
- Dr. Marcus Thorne (Elite Cataract & Glaucoma Microsurgeon)
- Dr. Samantha Al-Jamil (Retina specialist, pediatric ocular expert)

Support appointments, treatment explanations, emergency guidance (fast saline irrigation for chemicals, keep eye closed for trauma, immediate travel), and clinic policies (EMI starts at $150/month with zero percent interest for up to 24 months, accepts major premium insurances). Return professional, engaging replies. Do not make up facts outside eye care. Always insert a gentle clinical oversight disclaimer in details.`;

    const chatInput = formattedHistory[formattedHistory.length - 1]?.parts[0]?.text || "Hello";
    const history = formattedHistory.slice(0, formattedHistory.length - 1);

    const chatInstance = client.chats.create({
      model: "gemini-3.5-flash",
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      },
      history: history,
    });

    const response = await chatInstance.sendMessage({ message: chatInput });
    return res.json({ reply: response.text });
  } catch (err: any) {
    console.error("Gemini API Error:", err);
    return res.status(500).json({ error: "Ocular AI core failed: " + err.message });
  }
});

// API: Symptom checker using structural JSON schema from Gemini
app.post("/api/symptom-check", async (req, res) => {
  const { symptoms, age, duration } = req.body;
  if (!symptoms) {
    return res.status(400).json({ error: "Symptom description is required." });
  }

  const client = getGemini();

  if (!client) {
    // High-quality local heuristic diagnostic
    const sStr = symptoms.toLowerCase();
    let condition = "Ophthalmic Fatigue / Dry Eye";
    let risk = "Low";
    let urgency = "Schedule normal exam within 2-3 weeks.";
    let details = "Your symptoms suggest high exposure to ocular dryness or digital eye strain. We suggest keeping track of screen times, doing the 20-20-20 rule, and coming in for custom ocular hydration diagnostics.";
    let expert = "Dr. Evelyn Vance (Refractive & Tear Specialist)";
    let recommendedTests = ["Ocular Surface Interferometry", "Tear Osmolarity Analyzer"];

    if (sStr.includes("flash") || sStr.includes("floaters") || sStr.includes("curtain") || sStr.includes("shower of spot")) {
      condition = "Posterior Vitreous Detachment / Retinal Tear Warning";
      risk = "High";
      urgency = "URGENT intake required within 24 hours.";
      details = "Flashing lights and a sudden crop of dark floaters are hallmarks of mechanical vitreous traction on the retina. Immediate fundus dilation is highly advised to rule out tear or retinal detachments.";
      expert = "Dr. Samantha Al-Jamil (Retina Director)";
      recommendedTests = ["Dynamic Ultra-Widefield Scanning (Optomap)", "Optical Coherence Tomography (OCT)"];
    } else if (sStr.includes("blur") && sStr.includes("halo") && sStr.includes("night")) {
      condition = "Progressive Nuclear Sclerotic Cataract";
      risk = "Moderate";
      urgency = "Diagnostic exam within 5-7 days.";
      details = "Symptoms like glare around oncoming headlights at night and dual-image blur typically align with crystallizing human lens proteins. Blade-free refractive laser lens replacement will perfectly clear and brighten this.";
      expert = "Dr. Marcus Thorne (Cataract Specialist)";
      recommendedTests = ["Wavefront Corneal Aberrometry", "Slit Lamp Biomicroscopy"];
    } else if (sStr.includes("pain") || sStr.includes("severe") || sStr.includes("redness") || sStr.includes("pressure")) {
      condition = "Acute Angle-Closure Glaucoma Suspect";
      risk = "Critical";
      urgency = "IMMEDIATE EMERGENCY INTAKE - Call emergency ward.";
      details = "Severe persistent pain and intraocular pressure elevation (often combined with halo/nausea) requires emergency diagnostic tension measuring and topical anti-hypertensive droplets to prevent optical nerve damage.";
      expert = "Dr. Marcus Thorne (Glaucoma Specialist)";
      recommendedTests = ["Applanation Tonometry", "Gonioscopic Angle Examination"];
    }

    return res.json({
      success: true,
      diagnosis: {
        probableCondition: condition,
        severityLevel: risk,
        urgencyDescription: urgency,
        clinicalExplanation: details,
        expertSpecialist: expert,
        recommendedDiagnostics: recommendedTests,
        disclaimer: "DISCLAIMER: This analysis is an AI virtual screening simulator. It is NOT a substitute for professional clinical slit-lamp biometric observation.",
      },
    });
  }

  try {
    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Perform an intelligent medical ocular screening analysis of these symptoms:
Symptoms: "${symptoms}"
Age: ${age || "unspecified"} years
Duration: ${duration || "unspecified"}.

Provide a highly professional evaluation in clear JSON structure conforming to:
{
  "probableCondition": "name of possible condition",
  "severityLevel": "Low" | "Moderate" | "High" | "Critical",
  "urgencyDescription": "ideal timeframe for physical evaluation, e.g., Within 24 hours, normal schedule, etc.",
  "clinicalExplanation": "clear, beautiful medical but patient-readable explanation of why this happens and what is affected",
  "expertSpecialist": "Evelyn Vance (Refractive), Marcus Thorne (Cataract), or Samantha Al-Jamil (Retina)",
  "recommendedDiagnostics": ["Test 1", "Test 2"],
  "disclaimer": "This virtual screening is an advanced algorithmic filter. It does NOT constitute formal optical advice."
}
Return only JSON text.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["probableCondition", "severityLevel", "urgencyDescription", "clinicalExplanation", "expertSpecialist", "recommendedDiagnostics", "disclaimer"],
          properties: {
            probableCondition: { type: Type.STRING },
            severityLevel: { type: Type.STRING },
            urgencyDescription: { type: Type.STRING },
            clinicalExplanation: { type: Type.STRING },
            expertSpecialist: { type: Type.STRING },
            recommendedDiagnostics: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            disclaimer: { type: Type.STRING },
          },
        },
      },
    });

    const val = JSON.parse(response.text);
    return res.json({ success: true, diagnosis: val });
  } catch (err: any) {
    console.error("Symptom Checker API Error:", err);
    // Return fallback logic if Gemini API crashes inside parsing
    return res.status(500).json({ error: "Symptom checker analysis failed: " + err.message });
  }
});

// Setup Vite Dev server or Serve production assets
async function createApplication() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[AuraVision Core Server] running at http://localhost:${PORT}`);
    console.log(`[Mode] ${process.env.NODE_ENV === "production" ? "Production" : "Vite Development (HMR Disabled)"}`);
  });
}

createApplication().catch((err) => {
  console.error("Critical: Failed to launch AuraVision Server:", err);
});
